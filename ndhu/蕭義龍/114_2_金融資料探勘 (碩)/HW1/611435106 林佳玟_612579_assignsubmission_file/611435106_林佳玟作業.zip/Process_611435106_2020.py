# ============================================================
# 金融資料探勘 作業一：建構選擇權分析索引檔
# 學號：ABCDEFG ｜ 年度：2020
# ============================================================
# 本程式從原始資料（資料來源1.xlsx）出發，
# 逐步建構完整的 7 欄位選擇權分析索引檔。
# ============================================================

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import calendar
import os

# --- 設定 ---
STUDENT_ID = "ABCDEFG"
YEAR = 2020
INPUT_FILE = "資料來源1.xlsx"
OUTPUT_FILE = f"Index_{STUDENT_ID}_{YEAR}.xlsx"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)

print("=" * 60)
print(f"  金融資料探勘 作業一 — 索引檔建構程式")
print(f"  學號: {STUDENT_ID} ｜ 年度: {YEAR}")
print("=" * 60)


# ============================================================
# 步驟 1：讀入原始資料並確認年度範圍與資料筆數
# ============================================================
print("\n【步驟 1】讀入原始資料")
print("-" * 40)

df = pd.read_excel(INPUT_FILE)
print(f"  原始欄位: {list(df.columns)}")
print(f"  資料筆數: {len(df)} 筆")
print(f"  日期範圍: {df.iloc[0, 0]} ~ {df.iloc[-1, 0]}")
print(f"  收盤價範圍: {df.iloc[:, 1].min()} ~ {df.iloc[:, 1].max()}")


# ============================================================
# 步驟 2：整理日期格式並統一欄位名稱
# ============================================================
print("\n【步驟 2】整理日期格式與欄位名稱")
print("-" * 40)

# 重新命名欄位
df.columns = ["Date", "S0"]

# 確保 Date 為 datetime 格式
df["Date"] = pd.to_datetime(df["Date"])

# 排序確認
df = df.sort_values("Date").reset_index(drop=True)

print(f"  欄位已重新命名為: {list(df.columns)}")
print(f"  Date 型態: {df['Date'].dtype}")
print(f"  S0   型態: {df['S0'].dtype}")
print(f"  前 3 筆:")
for i in range(min(3, len(df))):
    print(f"    {df.loc[i, 'Date'].strftime('%Y-%m-%d')}  |  S0 = {df.loc[i, 'S0']}")


# ============================================================
# 步驟 3：建立每日檔名 File
# ============================================================
print("\n【步驟 3】建立 File 欄位")
print("-" * 40)

# 格式: OptionsDaily_yyyy_MM_dd.csv
df["File"] = df["Date"].apply(
    lambda d: f"OptionsDaily_{d.strftime('%Y_%m_%d')}.csv"
)

print(f"  檔名格式範例:")
for i in range(min(3, len(df))):
    print(f"    {df.loc[i, 'Date'].strftime('%Y-%m-%d')} → {df.loc[i, 'File']}")


# ============================================================
# 步驟 4：建立 Contract 與 ContractExpiryDate
# ============================================================
print("\n【步驟 4】建立 Contract 與 ContractExpiryDate")
print("-" * 40)


def get_third_wednesday(year, month):
    """
    計算指定年月的「第三個星期三」。
    臺指選擇權的到期日為每月第三個星期三。
    
    邏輯：
    1. 找出該月 1 號是星期幾
    2. 計算第一個星期三的日期
    3. 加上 14 天 = 第三個星期三
    """
    # calendar.weekday 回傳 0=Monday ... 6=Sunday
    first_day_weekday = calendar.weekday(year, month, 1)
    
    # 星期三 = 2 (Monday=0, Tuesday=1, Wednesday=2)
    # 計算第一個星期三是幾號
    if first_day_weekday <= 2:
        first_wednesday = 1 + (2 - first_day_weekday)
    else:
        first_wednesday = 1 + (7 - first_day_weekday + 2)
    
    # 第三個星期三 = 第一個星期三 + 14
    third_wednesday = first_wednesday + 14
    
    return datetime(year, month, third_wednesday)


def get_contract_info(trade_date):
    """
    根據交易日判定近月契約代碼與到期日。
    
    規則：
    - 若交易日 < 當月到期日 → 近月契約 = 當月
    - 若交易日 >= 當月到期日 → 近月契約 = 次月
    """
    year = trade_date.year
    month = trade_date.month
    
    # 當月的第三個星期三（到期日）
    current_expiry = get_third_wednesday(year, month)
    
    if trade_date < current_expiry:
        # 交易日在到期日之前 → 近月契約 = 當月
        contract = f"{year}{month:02d}"
        expiry_date = current_expiry
    else:
        # 交易日在到期日當天或之後 → 近月契約 = 次月
        if month == 12:
            next_year, next_month = year + 1, 1
        else:
            next_year, next_month = year, month + 1
        
        contract = f"{next_year}{next_month:02d}"
        expiry_date = get_third_wednesday(next_year, next_month)
    
    return contract, expiry_date


# 套用函數計算 Contract 和 ContractExpiryDate
contract_results = df["Date"].apply(
    lambda d: pd.Series(get_contract_info(d), index=["Contract", "ContractExpiryDate"])
)
df["Contract"] = contract_results["Contract"]
df["ContractExpiryDate"] = pd.to_datetime(contract_results["ContractExpiryDate"])

# 驗證：找出契約切換的日期
print(f"  契約切換點驗證:")
for i in range(1, len(df)):
    if df.loc[i, "Contract"] != df.loc[i - 1, "Contract"]:
        print(f"    {df.loc[i-1, 'Date'].strftime('%Y-%m-%d')} Contract={df.loc[i-1, 'Contract']}")
        print(f"    {df.loc[i,   'Date'].strftime('%Y-%m-%d')} Contract={df.loc[i,   'Contract']}  ← 切換")
        print()

# 列出所有到期日
unique_contracts = df[["Contract", "ContractExpiryDate"]].drop_duplicates()
print(f"  本年度契約到期日一覽:")
for _, row in unique_contracts.iterrows():
    print(f"    Contract {row['Contract']} → 到期日 {row['ContractExpiryDate'].strftime('%Y-%m-%d')}")


# ============================================================
# 步驟 5：計算 Maturity（距到期日曆日天數）
# ============================================================
print("\n【步驟 5】計算 Maturity")
print("-" * 40)

# Maturity = ContractExpiryDate - Date（日曆日天數）
df["Maturity"] = (df["ContractExpiryDate"] - df["Date"]).dt.days

print(f"  Maturity 計算方式: ContractExpiryDate - Date（日曆日）")
print(f"  Maturity 範圍: {df['Maturity'].min()} ~ {df['Maturity'].max()} 天")
print(f"  前 5 筆:")
for i in range(min(5, len(df))):
    print(f"    {df.loc[i, 'Date'].strftime('%Y-%m-%d')} → "
          f"{df.loc[i, 'ContractExpiryDate'].strftime('%Y-%m-%d')} = "
          f"{df.loc[i, 'Maturity']} 天")


# ============================================================
# 步驟 6：補入 Rf（無風險利率）
# ============================================================
print("\n【步驟 6】補入 Rf")
print("-" * 40)

# 從教師提供的參考檔讀取 Rf
# 說明：Rf 來源為央行短天期利率。2020 年央行於 3/19 降息，
#       因此 Rf 並非按月固定，而是在 3 月中從 0.0109 降為 0.0084。
#       故採用「按日期直接對應」方式合併，而非按月份分組。
rf_file = "Path_教學_修正Rf版.xlsx"
df_rf_ref = pd.read_excel(rf_file)
df_rf_ref.columns = ["Date_ref", "File_ref", "S0_ref", "Maturity_ref",
                      "Contract_ref", "ContractExpiryDate_ref", "Rf"]
df_rf_ref["Date_ref"] = pd.to_datetime(df_rf_ref["Date_ref"])

# 建立 日期 → Rf 對照表（逐日對應）
rf_daily = df_rf_ref.set_index("Date_ref")["Rf"].to_dict()

print(f"  Rf 資料來源: {rf_file}")
print(f"  Rf 對應方式: 按交易日逐日對應（因央行 2020/3/19 降息）")

# 顯示 Rf 變動點
rf_values = df_rf_ref[["Date_ref", "Rf"]].drop_duplicates(subset="Rf")
print(f"  Rf 變動紀錄:")
for _, row in rf_values.iterrows():
    print(f"    {row['Date_ref'].strftime('%Y-%m-%d')} 起: Rf = {row['Rf']}")

# 合併 Rf 到主表（按日期對應）
df["Rf"] = df["Date"].map(rf_daily)

# 檢查是否有缺值
rf_null_count = df["Rf"].isnull().sum()
if rf_null_count > 0:
    print(f"\n  ⚠️ 有 {rf_null_count} 筆 Rf 為空值！")
    print(f"     缺值月份: {df[df['Rf'].isnull()]['Date'].dt.to_period('M').unique()}")
else:
    print(f"\n  ✅ Rf 全部填入完成，無缺值")


# ============================================================
# 步驟 7：輸出最終年度索引檔
# ============================================================
print("\n【步驟 7】輸出最終索引檔")
print("-" * 40)

# 整理欄位順序
df_output = df[["Date", "File", "S0", "Contract", "ContractExpiryDate", "Maturity", "Rf"]].copy()

# 輸出 Excel
df_output.to_excel(OUTPUT_FILE, index=False, sheet_name=f"Index_{YEAR}")
print(f"  ✅ 已輸出: {OUTPUT_FILE}")
print(f"  總筆數: {len(df_output)} 筆")
print(f"  欄位: {list(df_output.columns)}")

# 同時輸出 CSV 備份
csv_output = OUTPUT_FILE.replace(".xlsx", ".csv")
df_output.to_csv(csv_output, index=False, encoding="utf-8-sig")
print(f"  ✅ CSV 備份: {csv_output}")


# ============================================================
# 成果展示：前 10 筆
# ============================================================
print("\n" + "=" * 60)
print("  成果展示：前 10 筆資料")
print("=" * 60)

pd.set_option("display.width", 120)
pd.set_option("display.max_columns", 10)

display_df = df_output.head(10).copy()
display_df["Date"] = display_df["Date"].dt.strftime("%Y-%m-%d")
display_df["ContractExpiryDate"] = display_df["ContractExpiryDate"].dt.strftime("%Y-%m-%d")
print(display_df.to_string(index=False))


# ============================================================
# 資料品質檢核
# ============================================================
print("\n" + "=" * 60)
print("  資料品質檢核")
print("=" * 60)

print(f"\n  1. 缺值檢查:")
for col in df_output.columns:
    null_count = df_output[col].isnull().sum()
    status = "✅ 無缺值" if null_count == 0 else f"⚠️ {null_count} 筆缺值"
    print(f"     {col}: {status}")

print(f"\n  2. Maturity 合理性:")
print(f"     最小值: {df_output['Maturity'].min()} 天")
print(f"     最大值: {df_output['Maturity'].max()} 天")
print(f"     負值筆數: {(df_output['Maturity'] < 0).sum()}")

print(f"\n  3. Contract 分佈:")
contract_counts = df_output["Contract"].value_counts().sort_index()
for contract, count in contract_counts.items():
    print(f"     {contract}: {count} 筆")

print(f"\n  4. S0 基本統計:")
print(f"     平均: {df_output['S0'].mean():.2f}")
print(f"     最小: {df_output['S0'].min():.2f}")
print(f"     最大: {df_output['S0'].max():.2f}")

print("\n" + "=" * 60)
print(f"  ✅ 程式執行完畢！索引檔已輸出至 {OUTPUT_FILE}")
print("=" * 60)
